/**
  ******************************************************************************
  * @file    zlg7290_i2c.h
  * @author  kevin_guo
  * @version V1.0.0
  * @date    12-15-2017
  * @brief   This file contains definitions for zlg7290_i2c.c
  ******************************************************************************
  * @attention
  ******************************************************************************  
  */ 
  
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DELAY_H 
#define __DELAY_H 

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macros -----------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
void Delay_Init(void);
void Delay_mS(unsigned short int nms);
void TimingDelay_Decrement(void);
#endif /* __DELAY_H */

/************************END OF FILE*************************/
