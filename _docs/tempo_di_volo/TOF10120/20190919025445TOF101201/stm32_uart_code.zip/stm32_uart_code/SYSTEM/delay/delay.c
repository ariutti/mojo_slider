/**
  ******************************************************************************
  * @file    delay.c
  * @author  kevin_guo
  * @version V1.0.0
  * @date    12-15-2017
  * @brief   This file provides functions to delay
  ******************************************************************************
  * @attention 
  ******************************************************************************
  */ 
  
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"	
#include <stm32f10x_conf.h>

#include "delay.h"

/* extern variables ----------------------------------------------------------*/
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
unsigned int TimingDelay;
/* Private function prototypes -----------------------------------------------*/
/* Private function ----------------------------------------------------------*/

/*******************************************************************************
* Function Name  : SysTick_Handler
* Description    : This function handles SysTick Handler.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/ 
void SysTick_Handler(void)
{
	TimingDelay_Decrement();	
}
/*******************************************************************************
* Function Name  : Delay_Init
* Description    : config delay function
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Delay_Init(void)	 
{
	RCC_ClocksTypeDef RCC_Clocks;

	/* Setup SysTick Timer for 1 msec interrupts  */
  RCC_GetClocksFreq(&RCC_Clocks);
  if (SysTick_Config(RCC_Clocks.SYSCLK_Frequency / 1000))
  {
    /* Capture error */
    while (1);
  }
  /* configure Systick priority */
	SCB->SHP[((uint32_t)(SysTick_IRQn) & 0xF)-4] = ((0x0B << (8 - __NVIC_PRIO_BITS)) & 0xff); /* set Priority for Cortex-M  System Interrupts */
}				
			
/*******************************************************************************
* Function Name  : Delay_mS
* Description    : delay n*mS when sysclk=72M,nms<=1864 
* Input          : nus-n*mS
* Output         : None
* Return         : None
*******************************************************************************/	
void Delay_mS(unsigned short int nms)
{	 	
  TimingDelay = nms;

  while (TimingDelay != 0);
    
} 

/*******************************************************************************
* Function Name  : TimingDelay_Decrement
* Description    : Decrements the TimingDelay variable
* Input          : nus-n*mS
* Output         : None
* Return         : None
*******************************************************************************/	
void TimingDelay_Decrement(void)
{
  if (TimingDelay != 0x00)
  {
    TimingDelay--;
  }
}

/************************END OF FILE*************************/
