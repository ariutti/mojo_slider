/**
  ******************************************************************************
  * @file    usart.h
  * @author  kevin_guo
  * @version V1.0.0
  * @date    12-15-2018
  * @brief   This file contains definitions for usart.c
  ******************************************************************************
  * @attention
  ******************************************************************************  
  */ 
  
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USART_H
#define __USART_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macros -----------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
void Uart_Init(unsigned int bound);
void Send_Data_To_UART1(char dat);

#endif /* __USART_H */

/************************END OF FILE*************************/

