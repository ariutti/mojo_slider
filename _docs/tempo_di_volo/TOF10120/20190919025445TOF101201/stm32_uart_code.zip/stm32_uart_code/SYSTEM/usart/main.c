/**
  ******************************************************************************
  * @file    main.c
  * @author  kevin_guo
  * @version V1.0.0
  * @date    12-15-2017
  * @brief   This file provides functions to main
  ******************************************************************************
  * @attention    
  ******************************************************************************
  */ 
  
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"	
#include <stm32f10x_conf.h>

#include "delay.h"
#include "usart.h"	

/* extern variables ----------------------------------------------------------*/
extern unsigned short int length_val;
extern unsigned char rxbuf[16],rxempty, rxcnt,rxflag,waitflag;
extern unsigned int timeout;
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private function ----------------------------------------------------------*/
//void BuzzerInit(void)
//{
//  GPIO_InitTypeDef  GPIO_InitStructure;
//	
//	//PB3 PB4 config as GPIO
//	//PA13 PA14 config as GPIO
//	//PD0 PD1 config as GPIO
//	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);  //ENABLE AFIO Clock
//	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);//SWD ENABLE,JTAG DISABLE
////	GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable,ENABLE);//SWD DISABLE,JTAG DISABLE
//	GPIO_PinRemapConfig(GPIO_Remap_PD01,ENABLE);
//	DBGMCU_Config(DBGMCU_CR_TRACE_IOEN,DISABLE);//DEFAUT: TRACE_IOEN=0
//  
//  /* Enable the GPIO Clock */
//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

//	/* Configure the GPIO pin */
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//  GPIO_Init(GPIOB, &GPIO_InitStructure);	
//	
//	GPIO_ResetBits(GPIOB, GPIO_Pin_4);
////	GPIO_SetBits(GPIOB, GPIO_Pin_4);
//}
/*******************************************************************************
* Function Name  : main
* Description    : main program body
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
int main(void)
{	 		
	unsigned char i;
	
//	BuzzerInit();
	Delay_Init();	    	 	//systick��ʼ��Ϊ1mS��������ʱ�ͳ�ʱ����	  	
	
	Uart_Init(9600);	 		//���ڳ�ʼ��Ϊ9600����ͨ����������ϵͳ�����ͻ�ȡϵͳ��Ϣ
		
	Send_Data_To_UART1('s');
	Send_Data_To_UART1('5');
	Send_Data_To_UART1('-');
	Send_Data_To_UART1('1');
	Send_Data_To_UART1('#'); //��Ϊ������ȡģʽ
	Delay_mS(10);
	waitflag=1;
	while(waitflag==1);
	waitflag=0; 
	Delay_mS(1000);
	rxcnt=0;
	while(1)
	{
		//ֻ����Ϊ������ȡģʽ���ŷ���r6#����
		Send_Data_To_UART1('r');
		Send_Data_To_UART1('6');
		Send_Data_To_UART1('#');//������ȡ��������
		timeout=10000;
		while((rxflag==0)&&(timeout--));
		//�������������ֻ�������������ѯrxflag��־
		if(rxflag)//���յ�1����Ч����
		{
			for(i=0; i<rxcnt; i++)
			{
				if(rxbuf[i]=='m')
				{
					if(rxbuf[i+1]=='m')	//ASCII��ת��Ϊ16�������ݣ���λmm
					{
						if((i>0)&&(rxbuf[i-1]>='0')&&(rxbuf[i-1]<='9'))
							length_val=rxbuf[i-1]-'0';
						if((i>1)&&(rxbuf[i-2]>='0')&&(rxbuf[i-2]<='9'))
							length_val+=(rxbuf[i-2]-'0')*10;
						if((i>2)&&(rxbuf[i-3]>='0')&&(rxbuf[i-3]<='9'))
							length_val+=(rxbuf[i-3]-'0')*100;
						if((i>3)&&(rxbuf[i-4]>='0')&&(rxbuf[i-4]<='9'))
							length_val+=(rxbuf[i-4]-'0')*1000;
						break;
					}
				}
			}
			rxflag = 0;
			rxcnt = 0;
		}
	}	
}

/************************END OF FILE*************************/